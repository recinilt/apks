// ========== ALARM SISTEMI ==========
// 3 katmanli: Bildirim + Normal Ses + Guclu Alarm (surekli calan)

var _alarmAudioCtx = null;
var _alarmOscillator = null;
var _alarmGain = null;
var _alarmInterval = null;
var _alarmActive = false;
var _vibrateInterval = null;

// AudioContext lazy init
function getAlarmAudioCtx() {
  if (!_alarmAudioCtx) {
    _alarmAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  // Resume if suspended (autoplay policy)
  if (_alarmAudioCtx.state === 'suspended') {
    _alarmAudioCtx.resume();
  }
  return _alarmAudioCtx;
}

// ========== NORMAL ALARM (kisa bip sesi) ==========
function playNormalAlarm() {
  _fn('playNormalAlarm');
  try {
    var ctx = getAlarmAudioCtx();
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    // 3 tonlu kisa alarm
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(1100, ctx.currentTime + 0.15);
    osc.frequency.setValueAtTime(1320, ctx.currentTime + 0.3);
    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.45);
    osc.frequency.setValueAtTime(1100, ctx.currentTime + 0.6);
    osc.frequency.setValueAtTime(1320, ctx.currentTime + 0.75);

    gain.gain.setValueAtTime(0.5, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.0);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 1.0);
  } catch(e) {
    console.warn('playNormalAlarm hata:', e);
  }

  // Titresim (varsa)
  try {
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200, 100, 200]);
    }
  } catch(e) {}
}

// ========== GUCLU ALARM (surekli calan, kullanici kapatana kadar) ==========
function playStrongAlarm() {
  _fn('playStrongAlarm');
  if (_alarmActive) return; // Zaten caliyorsa tekrar baslatma
  _alarmActive = true;

  // Ses dongusu: her 1.5 saniyede yuksek frekansta alarm
  _alarmInterval = setInterval(function() {
    try {
      var ctx = getAlarmAudioCtx();

      // Alarm pattern: yuksek-alcak-yuksek tekrarli
      var osc1 = ctx.createOscillator();
      var osc2 = ctx.createOscillator();
      var gain = ctx.createGain();

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      // Siren benzeri ses
      osc1.type = 'sawtooth';
      osc2.type = 'square';

      osc1.frequency.setValueAtTime(800, ctx.currentTime);
      osc1.frequency.linearRampToValueAtTime(1600, ctx.currentTime + 0.5);
      osc1.frequency.linearRampToValueAtTime(800, ctx.currentTime + 1.0);

      osc2.frequency.setValueAtTime(600, ctx.currentTime);
      osc2.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 0.5);
      osc2.frequency.linearRampToValueAtTime(600, ctx.currentTime + 1.0);

      gain.gain.setValueAtTime(0.7, ctx.currentTime);
      gain.gain.setValueAtTime(0.7, ctx.currentTime + 1.0);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);

      osc1.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 1.2);
      osc2.start(ctx.currentTime);
      osc2.stop(ctx.currentTime + 1.2);
    } catch(e) {
      console.warn('strongAlarm ses hata:', e);
    }
  }, 1500);

  // Surekli titresim
  _vibrateInterval = setInterval(function() {
    try {
      if (navigator.vibrate) {
        navigator.vibrate([500, 200, 500, 200, 500]);
      }
    } catch(e) {}
  }, 2000);
}

function stopStrongAlarm() {
  _fn('stopStrongAlarm');
  _alarmActive = false;

  if (_alarmInterval) {
    clearInterval(_alarmInterval);
    _alarmInterval = null;
  }
  if (_vibrateInterval) {
    clearInterval(_vibrateInterval);
    _vibrateInterval = null;
  }

  // Titresimi durdur
  try {
    if (navigator.vibrate) navigator.vibrate(0);
  } catch(e) {}
}

// ========== BILDIRIM GONDER ==========
function sendAlarmNotification(title, text, isStrong) {
  _fn('sendAlarmNotification');

  // cordova-plugin-local-notification varsa
  if (typeof cordova !== 'undefined' && cordova.plugins && cordova.plugins.notification && cordova.plugins.notification.local) {
    var notifId = Date.now() % 2147483647; // 32-bit int
    var opts = {
      id: notifId,
      title: title,
      text: text,
      androidSmallIcon: 'res://icon',
      androidChannelImportance: isStrong ? 'IMPORTANCE_HIGH' : 'IMPORTANCE_DEFAULT',
      androidChannelEnableVibration: true,
      lockscreen: true,
      wakeup: true,
      priority: 2
    };

    if (isStrong) {
      opts.androidChannelName = 'Guclu Alarm';
      opts.androidChannelId = 'ka_strong_alarm';
    } else {
      opts.androidChannelName = 'Konum Alarm';
      opts.androidChannelId = 'ka_normal_alarm';
    }

    try {
      cordova.plugins.notification.local.schedule(opts);
      console.log('Bildirim gonderildi:', title);
    } catch(e) {
      console.warn('Bildirim hatasi:', e);
    }
  } else {
    console.log('Bildirim plugin yok, sadece toast:', title);
  }
}

// ========== ALARM TETIKLEME (mesafe kontrol sonrasi cagirilir) ==========
function triggerAlarm(alarmDef, targetName, currentDist) {
  _fn('triggerAlarm');
  var distText = currentDist >= 1000 ? (currentDist / 1000).toFixed(1) + ' km' : Math.round(currentDist) + ' m';

  console.log('ALARM TETIKLENDI: ' + alarmDef.label + ' - ' + alarmDef.type + ' - mesafe: ' + distText);

  if (alarmDef.type === 'strong') {
    // Guclu alarm: tam ekran + surekli ses
    showAlarmFullscreen(targetName, alarmDef.label + ' kaldi!', distText);
    playStrongAlarm();
    sendAlarmNotification(
      'ALARM: ' + targetName,
      alarmDef.label + ' kaldi! Uygulamayi acin.',
      true
    );
  } else {
    // Normal alarm: bildirim + kisa ses
    playNormalAlarm();
    sendAlarmNotification(
      targetName + ' - ' + alarmDef.label,
      'Hedefe ' + alarmDef.label + ' kaldi',
      false
    );
  }
}

// ========== TAM EKRAN ALARM GOSTERIMI ==========
function showAlarmFullscreen(targetName, subtitle, dist) {
  _fn('showAlarmFullscreen');
  var el = document.getElementById('alarmFullscreen');
  document.getElementById('alarmFsTitle').textContent = targetName;
  document.getElementById('alarmFsSubtitle').textContent = subtitle;
  document.getElementById('alarmFsDist').textContent = dist;
  el.classList.add('show');
}

function stopAlarm() {
  _fn('stopAlarm');
  stopStrongAlarm();
  var el = document.getElementById('alarmFullscreen');
  el.classList.remove('show');
  if (typeof toast === 'function') toast('Alarm kapatildi', 'ok');
}

// ========== BILDIRIM IZNI ISTE ==========
function requestNotificationPermission() {
  _fn('requestNotificationPermission');

  // cordova-plugin-local-notification izin kontrolu
  if (typeof cordova !== 'undefined' && cordova.plugins && cordova.plugins.notification && cordova.plugins.notification.local) {
    try {
      cordova.plugins.notification.local.hasPermission(function(granted) {
        if (!granted) {
          cordova.plugins.notification.local.requestPermission(function(granted2) {
            console.log('Bildirim izni:', granted2 ? 'verildi' : 'reddedildi');
          });
        } else {
          console.log('Bildirim izni zaten var');
        }
      });
    } catch(e) {
      console.warn('Bildirim izni hatasi:', e);
    }
  }
}

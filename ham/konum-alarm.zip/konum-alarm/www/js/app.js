// ========== STATE ==========
var mainMap = null;
var mapTileLayer = null;
var routeLine = null;
var targetMk = null;
var myLocMk = null;
var myLoc = null;
var cihazHazir = false;
var bgGeo = null; // background geolocation plugin ref

// Navigasyon state
var navActive = false;
var navTargetId = null;
var navAlerts = []; // [{m, label, type, sent}]
var osrmDist = null;
var osrmDur = null;
var osrmLastUpdate = 0;
var OSRM_INTERVAL = 15000;

// Edit state
var editTargetId = null;
var pendingLL = null;

// Alarm settings temp (modal icin)
var _tempAlarms = [];

// ========== INIT ==========
document.addEventListener('deviceready', function() {
  _fn('deviceready');
  cihazHazir = true;

  try { StatusBar.backgroundColorByHexString('#0ea5e9'); }
  catch(e) { console.warn('StatusBar hatasi:', e); }

  try { requestNotificationPermission(); }
  catch(e) { console.warn('Bildirim izni hatasi:', e); }

  initApp();
}, false);

// Tarayici fallback (test icin)
window.addEventListener('load', function() {
  if (!cihazHazir) {
    setTimeout(function() {
      if (!cihazHazir) {
        console.log('deviceready gelmedi, tarayici modunda baslatiliyor');
        initApp();
      }
    }, 1500);
  }
});

function initApp() {
  _fn('initApp');
  loadTheme();

  // Kayitli navigasyon varsa devam et
  var ns = loadNavState();
  if (ns && ns.tid) {
    var t = getTarget(ns.tid);
    if (t) {
      navActive = true;
      navTargetId = ns.tid;
      navAlerts = ns.alerts || [];
      toast('Navigasyon kaldigi yerden devam ediyor...', 'inf');
      getMyLoc(function() {
        renderNav();
        startTracking();
      });
      return;
    } else {
      clearNavState();
    }
  }

  renderHome();
  getMyLoc();
}

// ========== KONUM ALMA ==========
function getMyLoc(cb) {
  _fn('getMyLoc');
  if (!navigator.geolocation) {
    toast('GPS desteklenmiyor', 'er');
    if (cb) cb();
    return;
  }
  navigator.geolocation.getCurrentPosition(function(p) {
    myLoc = { lat: p.coords.latitude, lng: p.coords.longitude };
    console.log('Konum alindi:', myLoc.lat.toFixed(5), myLoc.lng.toFixed(5));
    if (mainMap) mainMap.setView([myLoc.lat, myLoc.lng], 14);
    if (cb) cb();
  }, function(err) {
    console.warn('GPS hatasi:', err.message);
    toast('Konum alinamadi: ' + err.message, 'wn');
    if (cb) cb();
  }, { enableHighAccuracy: true, timeout: 15000 });
}

// ========== ARKA PLAN KONUM TAKIBI ==========
function startTracking() {
  _fn('startTracking');

  // Ekrani acik tut
  try {
    if (window.plugins && window.plugins.insomnia) {
      window.plugins.insomnia.keepAwake();
      console.log('Insomnia: ekran acik tutulacak');
    }
  } catch(e) { console.warn('Insomnia hatasi:', e); }

  // Background Geolocation Plugin
  if (typeof BackgroundGeolocation !== 'undefined') {
    bgGeo = BackgroundGeolocation;

    bgGeo.configure({
      locationProvider: BackgroundGeolocation.ACTIVITY_PROVIDER,
      desiredAccuracy: BackgroundGeolocation.HIGH_ACCURACY,
      stationaryRadius: 20,
      distanceFilter: 10,
      notificationTitle: 'Konum Alarm',
      notificationText: 'Navigasyon aktif - konum takip ediliyor',
      debug: false,
      interval: 5000,
      fastestInterval: 3000,
      activitiesInterval: 10000,
      stopOnTerminate: false,
      startForeground: true,
      startOnBoot: false,
      notificationIconColor: '#0ea5e9'
    });

    bgGeo.on('location', function(location) {
      myLoc = { lat: location.latitude, lng: location.longitude };
      onLocationUpdate();
      bgGeo.finish();
    });

    bgGeo.on('error', function(error) {
      console.error('BG Geo hata:', error.message);
    });

    bgGeo.start();
    console.log('BackgroundGeolocation baslatildi');
  } else {
    // Fallback: standart watchPosition
    console.log('BG Geo plugin yok, watchPosition kullaniliyor');
    startWatchPosition();
  }
}

var _watchId = null;
function startWatchPosition() {
  _fn('startWatchPosition');
  if (_watchId) navigator.geolocation.clearWatch(_watchId);
  _watchId = navigator.geolocation.watchPosition(function(p) {
    myLoc = { lat: p.coords.latitude, lng: p.coords.longitude };
    onLocationUpdate();
  }, function(err) {
    console.warn('watchPosition hata:', err.message);
  }, { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 });
}

function stopTracking() {
  _fn('stopTracking');

  if (bgGeo) {
    try { bgGeo.stop(); } catch(e) {}
    bgGeo = null;
  }
  if (_watchId) {
    navigator.geolocation.clearWatch(_watchId);
    _watchId = null;
  }

  // Ekran kilidi serbest
  try {
    if (window.plugins && window.plugins.insomnia) {
      window.plugins.insomnia.allowSleepAgain();
    }
  } catch(e) {}
}

// ========== KONUM GUNCELLEME (her yeni konum geldiginde) ==========
function onLocationUpdate() {
  if (!navActive || !navTargetId) return;

  var t = getTarget(navTargetId);
  if (!t) return;

  // OSRM throttle: 15sn'de bir guncelle
  var now = Date.now();
  if (now - osrmLastUpdate >= OSRM_INTERVAL) {
    updateOSRM({ lat: myLoc.lat, lng: myLoc.lng }, { lat: t.lat, lng: t.lng });
  }

  // Mesafe: OSRM varsa onu kullan, yoksa kus bakisi
  var dist = osrmDist !== null ? osrmDist : getDist(myLoc.lat, myLoc.lng, t.lat, t.lng);
  var distTxt = fmtDist(dist);
  var durTxt = osrmDur !== null ? fmtDur(osrmDur) : '';

  // Alarm kontrolu
  checkAlarms(dist, t);

  // UI guncelle (sadece nav ekranindaysak)
  if (mainMap) {
    addMyLocMarker();
    var chips = document.getElementById('mapChips');
    if (chips) {
      chips.innerHTML =
        '<div class="chip"><div class="cd" style="background:var(--ok)"></div>Nav Aktif</div>' +
        '<div class="chip"><div class="cd" style="background:var(--ac)"></div>' + distTxt + '</div>' +
        (durTxt ? '<div class="chip"><div class="cd" style="background:var(--in)"></div>~' + durTxt + '</div>' : '');
    }
    var ndl = document.getElementById('navDistLine');
    if (ndl) ndl.innerHTML = '&#128207; ' + distTxt + (durTxt ? ' . ~' + durTxt : '');
  }

  // TopBar'da mesafe goster
  var topInfo = document.getElementById('topInfo');
  if (topInfo && navActive) {
    topInfo.innerHTML = '<div class="dot-live"></div> ' + distTxt;
  }
}

// ========== ALARM KONTROLU ==========
function checkAlarms(dist, target) {
  _fn('checkAlarms');
  if (!navActive || !navAlerts) return;

  var changed = false;
  for (var i = 0; i < navAlerts.length; i++) {
    if (!navAlerts[i].sent && dist <= navAlerts[i].m) {
      navAlerts[i].sent = true;
      changed = true;

      // Alarmi tetikle
      triggerAlarm(navAlerts[i], target.ad, dist);
      toast(navAlerts[i].label + ' - Hedefe yaklasiyorsunuz!', 'ok');

      // Nav state kaydet
      persistNavState();

      // 100m altindaysa varis
      if (navAlerts[i].m <= 100) {
        toast('Hedefe ulastirildi! Navigasyon tamamlandi.', 'ok');
        setTimeout(function() { endNav(); }, 5000);
      }

      break; // Her seferde 1 alarm tetikle
    }
  }

  // UI guncelle
  if (changed) {
    var alertContainer = document.getElementById('navAlertBadges');
    if (alertContainer) {
      alertContainer.innerHTML = navAlerts.map(function(a) {
        return '<span class="badge ' + (a.sent ? 'done' : '') + '">' + a.label + (a.sent ? ' &#10003;' : '') + '</span>';
      }).join('');
    }
  }
}

function persistNavState() {
  _fn('persistNavState');
  if (navActive && navTargetId) {
    saveNavState({ tid: navTargetId, alerts: navAlerts });
  }
}

// ========== HARITA ==========
function getMapTile() {
  return document.documentElement.dataset.theme === 'dark'
    ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
    : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
}

function initMap(onReady) {
  _fn('initMap');
  if (mainMap) { mainMap.remove(); mainMap = null; }
  routeLine = null; targetMk = null; myLocMk = null;

  var center = myLoc ? [myLoc.lat, myLoc.lng] : [41.0082, 28.9784]; // Istanbul varsayilan
  setTimeout(function() {
    mainMap = L.map('mainMap', { zoomControl: true, attributionControl: false }).setView(center, 13);
    mapTileLayer = L.tileLayer(getMapTile(), { maxZoom: 19 }).addTo(mainMap);
    setTimeout(function() {
      mainMap.invalidateSize();
      if (onReady) onReady();
    }, 200);
  }, 50);
}

function addMyLocMarker() {
  if (!mainMap || !myLoc) return;
  if (myLocMk) mainMap.removeLayer(myLocMk);
  myLocMk = L.marker([myLoc.lat, myLoc.lng], {
    icon: L.divIcon({
      className: '',
      html: '<div style="width:18px;height:18px;border-radius:50%;background:#fff;border:4px solid #0ea5e9;box-shadow:0 0 12px rgba(14,165,233,.5);animation:pulse 2s infinite"></div>',
      iconSize: [18, 18], iconAnchor: [9, 9]
    })
  }).addTo(mainMap).bindPopup('Ben');
}

// ========== ANA SAYFA ==========
function renderHome() {
  _fn('renderHome');
  navActive = false;
  navTargetId = null;
  var navBtn = document.getElementById('navStatusBtn');
  if (navBtn) navBtn.style.display = 'none';

  var topInfo = document.getElementById('topInfo');
  if (topInfo) topInfo.innerHTML = '';

  var targets = loadTargets();

  document.getElementById('contentArea').innerHTML =
    '<div style="position:absolute;inset:0;overflow-y:auto;padding:56px 12px 12px;z-index:400;background:var(--bg0)">' +
    '<div style="max-width:600px;margin:0 auto;width:100%">' +
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:8px">' +
    '<h2 style="font-size:17px;font-weight:900;white-space:nowrap">&#128205; Hedeflerim</h2>' +
    '<button class="btn btn-ac btn-sm" onclick="openMapForTarget()">+ Hedef Ekle</button>' +
    '</div>' +
    (!targets.length
      ? '<div style="text-align:center;padding:40px 10px;color:var(--tx3)"><div style="font-size:36px;margin-bottom:8px">&#128506;&#65039;</div><p style="font-size:13px">Henuz hedef yok.<br>Haritadan yeni hedef ekleyin.</p></div>'
      : targets.map(function(t) {
          var alarmBadges = (t.alarms || []).map(function(a) {
            return '<span class="alarm-badge ' + (a.type === 'strong' ? 'strong' : '') + '">' + a.label + (a.type === 'strong' ? ' &#128276;' : '') + '</span>';
          }).join('');
          return '<div class="tgt-card">' +
            '<h3>&#128205; ' + escapeHtml(t.ad) + '</h3>' +
            '<div class="meta">' +
            '<span>&#127968; ' + escapeHtml((t.adres || '-').substring(0, 60)) + ((t.adres || '').length > 60 ? '...' : '') + '</span>' +
            '</div>' +
            (alarmBadges ? '<div class="alarm-badges">' + alarmBadges + '</div>' : '') +
            '<div class="acts">' +
            '<button class="btn btn-ok btn-sm" onclick="startNav(\'' + t.id + '\')">&#9654; Baslat</button>' +
            '<button class="btn btn-out btn-sm" onclick="openAlarmSettings(\'' + t.id + '\')">&#128276; Alarm</button>' +
            '<button class="btn btn-out btn-sm" onclick="editTarget(\'' + t.id + '\')">&#9999;&#65039;</button>' +
            '<button class="btn btn-er btn-sm" onclick="deleteTarget(\'' + t.id + '\')">&#128465;</button>' +
            '</div></div>';
        }).join('')) +
    '</div></div>';
}

// ========== HEDEF HARITA ==========
function openMapForTarget() {
  _fn('openMapForTarget');
  editTargetId = null;

  document.getElementById('contentArea').innerHTML =
    '<div class="map-wrap"><div id="mainMap"></div>' +
    '<div class="map-chips" id="mapChips"><div class="chip"><div class="cd" style="background:var(--ac)"></div>Haritaya tiklayarak hedef belirleyin</div></div>' +
    '<div class="map-srch"><input id="srchIn" placeholder="Adres ara..." onkeydown="if(event.key===\'Enter\')searchAddr()"><button onclick="searchAddr()">Ara</button></div>' +
    '</div>' +
    '<div class="panel" id="panel">' +
    '<div class="panel-drag" onclick="document.getElementById(\'panel\').classList.toggle(\'exp\')"><span></span></div>' +
    '<div class="panel-head"><div class="row"><button class="btn btn-out btn-sm" onclick="renderHome()">&#8592; Geri</button><span style="flex:1;font-weight:700;font-size:13px">Hedef Secimi</span></div></div>' +
    '<div class="panel-body" id="mapPanelBody" style="padding:12px">' +
    '<div style="text-align:center;padding:20px;color:var(--tx3)"><div style="font-size:28px;margin-bottom:6px">&#128070;</div><div style="font-size:12px">Haritada bir noktaya tiklayin</div></div>' +
    '</div></div>';

  initMap(function() {
    mainMap.on('click', onMapClick);
    if (myLoc) addMyLocMarker();
  });
}

function onMapClick(e) {
  _fn('onMapClick');
  pendingLL = e.latlng;
  editTargetId = null;
  document.getElementById('tgtMoT').textContent = 'Yeni Hedef';
  document.getElementById('tgtSaveBtn').textContent = 'Kaydet';
  document.getElementById('tgtName').value = '';
  document.getElementById('tgtAddr').value = 'Yukleniyor...';
  document.getElementById('tgtCoord').value = e.latlng.lat.toFixed(6) + ', ' + e.latlng.lng.toFixed(6);
  document.getElementById('tgtNote').value = '';
  openMo('targetMo');
  revGeo(e.latlng.lat, e.latlng.lng);
}

async function revGeo(lat, lng) {
  _fn('revGeo');
  try {
    var r = await fetch('https://nominatim.openstreetmap.org/reverse?lat=' + lat + '&lon=' + lng + '&format=json&addressdetails=1&accept-language=tr');
    var d = await r.json();
    document.getElementById('tgtAddr').value = d.display_name || '';
    if (!document.getElementById('tgtName').value) {
      var a = d.address || {};
      document.getElementById('tgtName').value = a.road || a.neighbourhood || a.suburb || 'Hedef';
    }
  } catch(e) {
    document.getElementById('tgtAddr').value = '';
  }
}

async function searchAddr() {
  _fn('searchAddr');
  var q = document.getElementById('srchIn').value.trim();
  if (!q) return;
  try {
    var r = await fetch('https://nominatim.openstreetmap.org/search?q=' + encodeURIComponent(q) + '&format=json&limit=1&accept-language=tr');
    var d = await r.json();
    if (d.length) mainMap.setView([+d[0].lat, +d[0].lon], 15);
    else toast('Bulunamadi', 'er');
  } catch(e) { toast('Arama hatasi', 'er'); }
}

// ========== HEDEF CRUD ==========
function saveTarget() {
  _fn('saveTarget');
  var nm = document.getElementById('tgtName').value.trim() || 'Hedef';
  var ad = document.getElementById('tgtAddr').value;
  var nt = document.getElementById('tgtNote').value.trim();

  var targets = loadTargets();

  if (editTargetId) {
    for (var i = 0; i < targets.length; i++) {
      if (targets[i].id === editTargetId) {
        targets[i].ad = nm;
        targets[i].adres = ad;
        targets[i].not = nt;
        break;
      }
    }
    toast('Guncellendi', 'ok');
  } else {
    var coords = document.getElementById('tgtCoord').value.split(',').map(Number);
    targets.push({
      id: 'h_' + Date.now(),
      ad: nm,
      adres: ad,
      lat: coords[0],
      lng: coords[1],
      not: nt,
      alarms: JSON.parse(JSON.stringify(DEFAULT_ALARMS))
    });
    toast('Hedef eklendi!', 'ok');
  }

  saveTargets(targets);
  closeMo('targetMo');
  renderHome();
}

function editTarget(id) {
  _fn('editTarget');
  var t = getTarget(id);
  if (!t) return;
  editTargetId = id;
  document.getElementById('tgtMoT').textContent = 'Hedef Duzenle';
  document.getElementById('tgtSaveBtn').textContent = 'Guncelle';
  document.getElementById('tgtName').value = t.ad;
  document.getElementById('tgtAddr').value = t.adres || '';
  document.getElementById('tgtCoord').value = t.lat.toFixed(6) + ', ' + t.lng.toFixed(6);
  document.getElementById('tgtNote').value = t.not || '';
  openMo('targetMo');
}

function deleteTarget(id) {
  _fn('deleteTarget');
  if (!confirm('Bu hedefi silmek istediginize emin misiniz?')) return;
  var targets = loadTargets().filter(function(t) { return t.id !== id; });
  saveTargets(targets);
  renderHome();
  toast('Silindi', 'inf');
}

// ========== ALARM AYARLARI MODAL ==========
function openAlarmSettings(targetId) {
  _fn('openAlarmSettings');
  var t = getTarget(targetId);
  if (!t) return;

  _tempAlarms = JSON.parse(JSON.stringify(t.alarms || DEFAULT_ALARMS));
  editTargetId = targetId;

  renderAlarmModal();
  openMo('alarmMo');
}

function renderAlarmModal() {
  _fn('renderAlarmModal');
  var html = '<div style="margin-bottom:12px;font-size:12px;color:var(--tx2)">Her mesafe icin alarm turunu secin. Guclu alarm kullaniciyi uyandirmak icin surekli calar.</div>';

  for (var i = 0; i < _tempAlarms.length; i++) {
    html += '<div class="alarm-row">' +
      '<span class="dist-label">' + _tempAlarms[i].label + '</span>' +
      '<select onchange="updateTempAlarm(' + i + ', this.value)">' +
      '<option value="normal"' + (_tempAlarms[i].type === 'normal' ? ' selected' : '') + '>Normal (bip + bildirim)</option>' +
      '<option value="strong"' + (_tempAlarms[i].type === 'strong' ? ' selected' : '') + '>Guclu (surekli alarm)</option>' +
      '<option value="off"' + (_tempAlarms[i].type === 'off' ? ' selected' : '') + '>Kapali</option>' +
      '</select>' +
      '<button class="remove-alarm" onclick="removeTempAlarm(' + i + ')">&#10005;</button>' +
      '</div>';
  }

  html += '<div class="add-alarm-row">' +
    '<input id="newAlarmDist" type="number" placeholder="Mesafe (metre)" min="50" step="50">' +
    '<select id="newAlarmType">' +
    '<option value="normal">Normal</option>' +
    '<option value="strong">Guclu</option>' +
    '</select>' +
    '<button class="btn btn-ac btn-sm" onclick="addTempAlarm()">+</button>' +
    '</div>';

  document.getElementById('alarmBody').innerHTML = html;
}

function updateTempAlarm(idx, val) {
  _fn('updateTempAlarm');
  _tempAlarms[idx].type = val;
}

function removeTempAlarm(idx) {
  _fn('removeTempAlarm');
  _tempAlarms.splice(idx, 1);
  renderAlarmModal();
}

function addTempAlarm() {
  _fn('addTempAlarm');
  var distInput = document.getElementById('newAlarmDist');
  var typeInput = document.getElementById('newAlarmType');
  var m = parseInt(distInput.value);
  if (!m || m < 50) { toast('Gecersiz mesafe (min 50m)', 'wn'); return; }

  // Kontrol: ayni mesafe var mi
  for (var i = 0; i < _tempAlarms.length; i++) {
    if (_tempAlarms[i].m === m) { toast('Bu mesafe zaten var', 'wn'); return; }
  }

  var label = m >= 1000 ? (m / 1000) + ' km' : m + ' m';
  _tempAlarms.push({ m: m, label: label, type: typeInput.value });

  // Buyukten kucuge sirala
  _tempAlarms.sort(function(a, b) { return b.m - a.m; });

  distInput.value = '';
  renderAlarmModal();
  toast('Alarm eklendi', 'ok');
}

function saveAlarmSettings() {
  _fn('saveAlarmSettings');
  var targets = loadTargets();
  for (var i = 0; i < targets.length; i++) {
    if (targets[i].id === editTargetId) {
      // 'off' olanlari filtrele
      targets[i].alarms = _tempAlarms.filter(function(a) { return a.type !== 'off'; });
      break;
    }
  }
  saveTargets(targets);
  closeMo('alarmMo');
  renderHome();
  toast('Alarm ayarlari kaydedildi', 'ok');
}

// ========== NAVIGASYON ==========
function startNav(tid) {
  _fn('startNav');
  var t = getTarget(tid);
  if (!t) { toast('Hedef bulunamadi', 'er'); return; }
  if (!myLoc) { toast('Konum alinamadi, bekleyin...', 'wn'); getMyLoc(); return; }

  navActive = true;
  navTargetId = tid;
  osrmDist = null;
  osrmDur = null;
  osrmLastUpdate = 0;

  // Alarm state'ini hazirla
  navAlerts = (t.alarms || DEFAULT_ALARMS).map(function(a) {
    return { m: a.m, label: a.label, type: a.type, sent: false };
  });

  persistNavState();
  renderNav();
  startTracking();
}

function renderNav() {
  _fn('renderNav');
  var t = getTarget(navTargetId);
  if (!t) return;

  var navBtn = document.getElementById('navStatusBtn');
  if (navBtn) { navBtn.style.display = ''; navBtn.classList.add('active-nav'); }

  var dist = osrmDist !== null ? osrmDist : (myLoc ? getDist(myLoc.lat, myLoc.lng, t.lat, t.lng) : null);
  var distTxt = dist !== null ? fmtDist(dist) : 'Hesaplaniyor...';
  var durTxt = osrmDur !== null ? fmtDur(osrmDur) : '';

  document.getElementById('contentArea').innerHTML =
    '<div class="map-wrap"><div id="mainMap"></div>' +
    '<div class="map-chips" id="mapChips">' +
    '<div class="chip"><div class="cd" style="background:var(--ok)"></div>Nav Aktif</div>' +
    '<div class="chip"><div class="cd" style="background:var(--ac)"></div>' + distTxt + '</div>' +
    (durTxt ? '<div class="chip"><div class="cd" style="background:var(--in)"></div>~' + durTxt + '</div>' : '') +
    '</div></div>' +
    '<div class="panel" id="panel">' +
    '<div class="panel-drag" onclick="document.getElementById(\'panel\').classList.toggle(\'exp\')"><span></span></div>' +
    '<div style="padding:8px 12px 0">' +
    '<div class="nav-bar"><div class="info">' +
    '<div class="lbl">&#128205; Hedef</div>' +
    '<div class="val">' + escapeHtml(t.ad) + '</div>' +
    '<div id="navDistLine" style="font-size:10px;opacity:.8;margin-top:3px">&#128207; ' + distTxt + (durTxt ? ' . ~' + durTxt : '') + '</div>' +
    '<div class="nav-alert" id="navAlertBadges">' + navAlerts.map(function(a) {
      return '<span class="badge ' + (a.sent ? 'done' : '') + '">' + a.label + (a.sent ? ' &#10003;' : '') + '</span>';
    }).join('') + '</div>' +
    '</div><div style="text-align:right"><div style="font-size:22px">&#129517;</div></div></div></div>' +
    '<div class="panel-body" style="padding:6px 12px">' +
    (t.adres ? '<div style="font-size:10px;color:var(--tx2);margin-bottom:6px;word-break:break-word">&#127968; ' + escapeHtml(t.adres) + '</div>' : '') +
    (t.not ? '<div style="font-size:10px;color:var(--tx2);margin-bottom:6px">&#128221; ' + escapeHtml(t.not) + '</div>' : '') +
    '</div>' +
    '<div style="padding:8px 12px;border-top:1px solid var(--bd)"><button class="btn btn-er" onclick="endNav()">&#9209; Navigasyonu Bitir</button></div>' +
    '</div>';

  initMap(function() {
    var tIcon = L.divIcon({
      className: '',
      html: '<div style="width:28px;height:28px;border-radius:50%;background:#ef4444;color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;box-shadow:0 2px 10px rgba(239,68,68,.5);border:3px solid #fff">&#127919;</div>',
      iconSize: [28, 28], iconAnchor: [14, 14]
    });
    targetMk = L.marker([t.lat, t.lng], { icon: tIcon }).addTo(mainMap).bindPopup('<b>' + escapeHtml(t.ad) + '</b>');

    // Alarm yaricaplarini ciz
    (t.alarms || []).forEach(function(a) {
      var color = a.type === 'strong' ? '#ef4444' : '#0ea5e9';
      L.circle([t.lat, t.lng], {
        radius: a.m, color: color, fillColor: color,
        fillOpacity: 0.05, weight: 1, dashArray: '5,5'
      }).addTo(mainMap).bindPopup(a.label);
    });

    if (myLoc) {
      addMyLocMarker();
      mainMap.fitBounds([[myLoc.lat, myLoc.lng], [t.lat, t.lng]], { padding: [50, 50] });
      drawRoute(myLoc, t);
    }
  });
}

function showNavPanel() {
  _fn('showNavPanel');
  if (navActive) renderNav();
}

function endNav() {
  _fn('endNav');
  navActive = false;
  navTargetId = null;
  osrmDist = null;
  osrmDur = null;
  osrmLastUpdate = 0;
  clearNavState();
  stopTracking();

  var navBtn = document.getElementById('navStatusBtn');
  if (navBtn) { navBtn.style.display = 'none'; navBtn.classList.remove('active-nav'); }

  toast('Navigasyon bitti', 'inf');
  renderHome();
}

// ========== OSRM ROTA ==========
async function drawRoute(from, to) {
  _fn('drawRoute');
  if (routeLine) { mainMap.removeLayer(routeLine); routeLine = null; }
  try {
    var cs = from.lng + ',' + from.lat + ';' + to.lng + ',' + to.lat;
    var r = await fetch('https://router.project-osrm.org/route/v1/driving/' + cs + '?overview=full&geometries=geojson');
    var data = await r.json();
    if (data.code === 'Ok') {
      routeLine = L.geoJSON(data.routes[0].geometry, { style: { color: '#0ea5e9', weight: 5, opacity: .8 } }).addTo(mainMap);
      osrmDist = data.routes[0].distance;
      osrmDur = data.routes[0].duration;
      osrmLastUpdate = Date.now();
    } else {
      routeLine = L.polyline([[from.lat, from.lng], [to.lat, to.lng]], { color: '#0ea5e9', weight: 4, opacity: .6, dashArray: '8' }).addTo(mainMap);
    }
  } catch(e) {
    routeLine = L.polyline([[from.lat, from.lng], [to.lat, to.lng]], { color: '#0ea5e9', weight: 4, opacity: .6, dashArray: '8' }).addTo(mainMap);
  }
}

async function updateOSRM(from, to) {
  _fn('updateOSRM');
  try {
    var cs = from.lng + ',' + from.lat + ';' + to.lng + ',' + to.lat;
    var r = await fetch('https://router.project-osrm.org/route/v1/driving/' + cs + '?overview=full&geometries=geojson');
    var data = await r.json();
    if (data.code === 'Ok') {
      osrmDist = data.routes[0].distance;
      osrmDur = data.routes[0].duration;
      osrmLastUpdate = Date.now();
      if (mainMap) {
        if (routeLine) mainMap.removeLayer(routeLine);
        routeLine = L.geoJSON(data.routes[0].geometry, { style: { color: '#0ea5e9', weight: 5, opacity: .8 } }).addTo(mainMap);
      }
    }
  } catch(e) {}
}

// ========== TEMA ==========
function toggleTheme() {
  _fn('toggleTheme');
  var d = document.documentElement;
  var isDark = d.dataset.theme === 'dark';
  if (isDark) {
    delete d.dataset.theme;
    document.getElementById('themeBtn').textContent = '\uD83C\uDF19';
    localStorage.setItem(KA_THEME_KEY, 'light');
  } else {
    d.dataset.theme = 'dark';
    document.getElementById('themeBtn').textContent = '\u2600\uFE0F';
    localStorage.setItem(KA_THEME_KEY, 'dark');
  }
  if (mainMap && mapTileLayer) {
    mainMap.removeLayer(mapTileLayer);
    mapTileLayer = L.tileLayer(getMapTile(), { maxZoom: 19 }).addTo(mainMap);
  }
}

function loadTheme() {
  _fn('loadTheme');
  var t = localStorage.getItem(KA_THEME_KEY);
  if (t === 'dark') {
    document.documentElement.dataset.theme = 'dark';
    var b = document.getElementById('themeBtn');
    if (b) b.textContent = '\u2600\uFE0F';
  }
}

// ========== AYARLAR ==========
function showSettings() {
  _fn('showSettings');
  openMo('settingsMo');
}

function clearAllData() {
  _fn('clearAllData');
  if (!confirm('Tum hedefler ve ayarlar silinecek. Emin misiniz?')) return;
  if (navActive) endNav();
  localStorage.removeItem(KA_TARGETS_KEY);
  localStorage.removeItem(KA_NAVSTATE_KEY);
  renderHome();
  toast('Tum veriler silindi', 'inf');
}

// ========== YARDIMCI FONKSIYONLAR ==========
function getDist(lat1, lng1, lat2, lng2) {
  var R = 6371000;
  var dLat = (lat2 - lat1) * Math.PI / 180;
  var dLon = (lng2 - lng1) * Math.PI / 180;
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function fmtDist(m) {
  return m >= 1000 ? (m / 1000).toFixed(1) + ' km' : Math.round(m) + ' m';
}

function fmtDur(s) {
  if (s < 60) return '<1 dk';
  var h = Math.floor(s / 3600);
  var m = Math.round((s % 3600) / 60);
  return h ? h + ' sa ' + m + ' dk' : m + ' dk';
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function openMo(id) {
  _fn('openMo');
  document.getElementById(id).classList.add('show');
}

function closeMo(id) {
  _fn('closeMo');
  document.getElementById(id).classList.remove('show');
}

function toast(m, t) {
  t = t || 'inf';
  var icons = { ok: '\u2705', er: '\u274C', inf: '\u2139\uFE0F', wn: '\u26A0\uFE0F' };
  var w = document.getElementById('toastW');
  var e = document.createElement('div');
  e.className = 'toast ' + t;
  e.innerHTML = '<span>' + (icons[t] || icons.inf) + '</span><span>' + m + '</span>';
  w.appendChild(e);
  setTimeout(function() {
    e.style.opacity = '0';
    e.style.transform = 'translateX(100%)';
    e.style.transition = 'all .3s';
    setTimeout(function() { e.remove(); }, 300);
  }, 4000);
}

// Modal disina tikla kapat
document.querySelectorAll('.mo').forEach(function(m) {
  m.addEventListener('click', function(e) {
    if (e.target === m) m.classList.remove('show');
  });
});

// ========== BACK BUTTON ==========
document.addEventListener('backbutton', function(e) {
  _fn('backbutton');
  e.preventDefault();

  // Acik modal varsa kapat
  var openModals = document.querySelectorAll('.mo.show');
  if (openModals.length) {
    openModals[openModals.length - 1].classList.remove('show');
    return;
  }

  // Alarm ekrani aciksa kapat
  var alarmFs = document.getElementById('alarmFullscreen');
  if (alarmFs && alarmFs.classList.contains('show')) {
    stopAlarm();
    return;
  }

  // Navigasyondaysa ana sayfaya don
  if (navActive) {
    renderHome();
    return;
  }

  // Ana sayfadaysa arka plana gonder
  arkaPlanaGonder();
}, false);

// ========== ARKA PLANA GONDER ==========
function arkaPlanaGonder() {
  _fn('arkaPlanaGonder');
  if (window.mayflower && mayflower.moveTaskToBack) {
    mayflower.moveTaskToBack();
  }
}

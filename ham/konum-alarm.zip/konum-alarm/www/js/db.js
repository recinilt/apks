// ========== LOGGER - Kalici Ring Buffer (her zaman aktif) ==========
var _logBuffer = [];
var _LOG_MAX = 1000;
var _LOG_STORAGE_KEY = 'ka_logBuffer';
var _logDirty = false;
var _logFlushTimer = null;

try {
  var _saved = localStorage.getItem(_LOG_STORAGE_KEY);
  if (_saved) _logBuffer = JSON.parse(_saved);
} catch(e) {}

function _logEkle(seviye, args) {
  var zaman = new Date().toISOString().substr(11, 12);
  var mesaj = '';
  for (var i = 0; i < args.length; i++) {
    if (i > 0) mesaj += ' ';
    try {
      if (typeof args[i] === 'object') mesaj += JSON.stringify(args[i]);
      else mesaj += String(args[i]);
    } catch (e) { mesaj += '[object]'; }
  }
  _logBuffer.push(zaman + ' [' + seviye + '] ' + mesaj);
  if (_logBuffer.length > _LOG_MAX) _logBuffer.shift();
  _logDirty = true;
}

function _fn(name) { _logEkle('FN', [name]); }

function _logFlush() {
  if (!_logDirty) return;
  try { localStorage.setItem(_LOG_STORAGE_KEY, JSON.stringify(_logBuffer)); }
  catch(e) {}
  _logDirty = false;
}

_logFlushTimer = setInterval(_logFlush, 5000);

var _origLog = console.log;
var _origWarn = console.warn;
var _origError = console.error;
console.log = function() { _logEkle('LOG', arguments); _origLog.apply(console, arguments); };
console.warn = function() { _logEkle('WRN', arguments); _origWarn.apply(console, arguments); };
console.error = function() { _logEkle('ERR', arguments); _origError.apply(console, arguments); };

window.addEventListener('error', function(e) {
  _logEkle('ERR', ['UNCAUGHT: ' + (e.message || '') + ' @ ' + (e.filename || '') + ':' + (e.lineno || '')]);
  _logFlush();
});
window.addEventListener('unhandledrejection', function(e) {
  _logEkle('ERR', ['UNHANDLED_PROMISE: ' + (e.reason ? (e.reason.message || e.reason) : 'unknown')]);
  _logFlush();
});

document.addEventListener('pause', function() {
  _logEkle('LOG', ['APP_LIFECYCLE: pause']);
  _logFlush();
}, false);
document.addEventListener('resume', function() {
  _logEkle('LOG', ['APP_LIFECYCLE: resume']);
}, false);
window.addEventListener('beforeunload', function() {
  _logEkle('LOG', ['APP_LIFECYCLE: beforeunload']);
  _logFlush();
});

console.log('APP_LIFECYCLE: db.js yuklendi (' + new Date().toISOString() + ')');
// ========== LOGGER SONU ==========


// ========== VERI KATMANI (localStorage) ==========
var KA_TARGETS_KEY = 'ka_targets';
var KA_NAVSTATE_KEY = 'ka_navstate';
var KA_THEME_KEY = 'ka_theme';

// Varsayilan alarm mesafeleri (yeni hedef icin)
var DEFAULT_ALARMS = [
  { m: 5000, label: '5 km', type: 'normal' },
  { m: 3000, label: '3 km', type: 'normal' },
  { m: 1000, label: '1 km', type: 'strong' },
  { m: 500, label: '500 m', type: 'strong' },
  { m: 100, label: '100 m', type: 'strong' }
];

function loadTargets() {
  _fn('loadTargets');
  try {
    var raw = localStorage.getItem(KA_TARGETS_KEY);
    if (raw) return JSON.parse(raw);
  } catch(e) { console.error('loadTargets hata:', e); }
  return [];
}

function saveTargets(targets) {
  _fn('saveTargets');
  try {
    localStorage.setItem(KA_TARGETS_KEY, JSON.stringify(targets));
  } catch(e) { console.error('saveTargets hata:', e); }
}

function getTarget(id) {
  var targets = loadTargets();
  for (var i = 0; i < targets.length; i++) {
    if (targets[i].id === id) return targets[i];
  }
  return null;
}

function saveNavState(state) {
  _fn('saveNavState');
  try {
    localStorage.setItem(KA_NAVSTATE_KEY, JSON.stringify(state));
  } catch(e) {}
}

function loadNavState() {
  _fn('loadNavState');
  try {
    var raw = localStorage.getItem(KA_NAVSTATE_KEY);
    if (raw) return JSON.parse(raw);
  } catch(e) {}
  return null;
}

function clearNavState() {
  _fn('clearNavState');
  localStorage.removeItem(KA_NAVSTATE_KEY);
}


// ========== HATA RAPORU ==========
function hataRaporuOlustur() {
  var satirlar = [];
  satirlar.push('=== KONUM ALARM - HATA RAPORU ===');
  satirlar.push('Tarih: ' + new Date().toISOString());
  satirlar.push('');
  satirlar.push('--- CIHAZ ---');
  try {
    if (typeof device !== 'undefined') {
      satirlar.push('Platform: ' + (device.platform || '?'));
      satirlar.push('Versiyon: ' + (device.version || '?'));
      satirlar.push('Model: ' + (device.model || '?'));
      satirlar.push('Manufacturer: ' + (device.manufacturer || '?'));
    } else {
      satirlar.push('Platform: ' + navigator.platform);
      satirlar.push('UserAgent: ' + navigator.userAgent.substr(0, 120));
    }
  } catch (e) { satirlar.push('Cihaz bilgisi alinamadi'); }
  satirlar.push('Ekran: ' + screen.width + 'x' + screen.height);
  satirlar.push('Online: ' + navigator.onLine);
  satirlar.push('');
  satirlar.push('--- UYGULAMA DURUMU ---');
  satirlar.push('Hedef Sayisi: ' + loadTargets().length);
  satirlar.push('Nav Aktif: ' + (loadNavState() ? 'EVET' : 'HAYIR'));
  satirlar.push('');
  satirlar.push('--- LOGLAR (son ' + _logBuffer.length + ' satir) ---');
  for (var i = 0; i < _logBuffer.length; i++) {
    satirlar.push(_logBuffer[i]);
  }
  return satirlar.join('\n');
}

function hataRaporuGonder() {
  _fn('hataRaporuGonder');
  var raporText = hataRaporuOlustur();
  var dosyaAdi = 'konum_alarm_rapor_' + new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-') + '.txt';

  if (window.plugins && window.plugins.socialsharing) {
    var base64 = btoa(unescape(encodeURIComponent(raporText)));
    var dataUri = 'df:' + dosyaAdi + ';data:text/plain;base64,' + base64;
    window.plugins.socialsharing.shareWithOptions({
      files: [dataUri],
      subject: 'Konum Alarm - Hata Raporu',
      chooserTitle: 'Hata raporunu gonder'
    }, function() {
      if (typeof toast === 'function') toast('Rapor gonderildi', 'ok');
    }, function() {
      if (typeof toast === 'function') toast('Gonderim iptal edildi', 'wn');
    });
  } else {
    // Tarayici fallback
    var blob = new Blob([raporText], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = dosyaAdi; a.click();
    URL.revokeObjectURL(url);
    if (typeof toast === 'function') toast('Rapor indirildi', 'ok');
  }
}
